# Check Exchange Cases


## File: Bitmart Data Set


- Case 0001
	-	Line Number: 367.
	- 	Hash: `0x56c82e4137c0ae73150f8e7753f3e3f191d43dde8b761d4f273793c7cbad6635`.
	-	Token: `RSR`.
	-	Amount: `13870304.45`.
	-	Amount USD by Auto Exchange: 0.
	-	Amount by Manual Exchange: 
- Case 0002


